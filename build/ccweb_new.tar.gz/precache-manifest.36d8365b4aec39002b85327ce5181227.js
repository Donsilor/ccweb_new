self.__precacheManifest = [
  {
    "revision": "039a02eb1ee3ca28f193abd720a64f0d",
    "url": "/ccweb_new/static/media/logo.039a02eb.png"
  },
  {
    "revision": "781d68efe1f972060ab12108b1c81ad8",
    "url": "/ccweb_new/static/media/logo-blue.781d68ef.png"
  },
  {
    "revision": "e8edc9aad522324552d5380ba7dc54bc",
    "url": "/ccweb_new/static/media/login-bg.e8edc9aa.jpg"
  },
  {
    "revision": "21387eb9ce6e67d717b3",
    "url": "/ccweb_new/static/js/runtime~main.21387eb9.js"
  },
  {
    "revision": "57edd2e3ec95ae3e5d9c",
    "url": "/ccweb_new/static/js/main.57edd2e3.chunk.js"
  },
  {
    "revision": "5d57511e567cd665aea6",
    "url": "/ccweb_new/static/js/1.5d57511e.chunk.js"
  },
  {
    "revision": "57edd2e3ec95ae3e5d9c",
    "url": "/ccweb_new/static/css/main.f9986577.chunk.css"
  },
  {
    "revision": "5d57511e567cd665aea6",
    "url": "/ccweb_new/static/css/1.32c9665f.chunk.css"
  },
  {
    "revision": "be651bf1512bfe13a247978c2bad3fd4",
    "url": "/ccweb_new/index.html"
  }
];